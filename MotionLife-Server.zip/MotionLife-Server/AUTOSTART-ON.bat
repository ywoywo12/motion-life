@echo off
chcp 65001 >nul
set "S=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MotionLife-Server.bat"
(
  echo @echo off
  echo cd /d "%~dp0"
  echo start "Motion Life - Server" /min cmd /c "node server.js"
) > "%S%"
echo   Done. The server will start automatically every time this laptop turns on.
pause
