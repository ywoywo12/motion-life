@echo off
chcp 65001 >nul
net session >nul 2>&1
if errorlevel 1 (
  echo   Right-click this file and choose "Run as administrator".
  pause
  exit /b
)
netsh advfirewall firewall delete rule name="Motion Life Server" >nul 2>&1
netsh advfirewall firewall add rule name="Motion Life Server" dir=in action=allow protocol=TCP localport=8080,8443 profile=private,domain
echo   Done. Other devices on the clinic Wi-Fi can now reach the server.
pause
