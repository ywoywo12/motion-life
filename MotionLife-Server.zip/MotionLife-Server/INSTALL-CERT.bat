@echo off
chcp 65001 >nul
title Motion Life - Install center certificate
cd /d "%~dp0"
if not exist "data\ca.pem" ( echo   Start the server first ^(START-SERVER.bat^), then run this file again. & pause & exit /b )
certutil -user -addstore -f Root "data\ca.pem"
echo.
echo   Done. Close Chrome completely and open https://192.168.1.40:8443 again.
pause
