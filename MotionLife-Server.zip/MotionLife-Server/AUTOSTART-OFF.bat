@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MotionLife-Server.bat" >nul 2>&1
echo   Auto-start removed.
pause
