@echo off
chcp 65001 >nul
title Motion Life - Server
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js is not installed. Opening the download page...
  echo   Install the LTS version, then run this file again.
  start "" "https://nodejs.org/en/download"
  pause
  exit /b
)
node server.js
pause
